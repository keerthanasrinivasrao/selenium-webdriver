package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
public class UserLoginPage {
	WebDriver driver;	

	By email= By.id("input-email");
	By password = By.id("input-password");
	By loginbutton = By.cssSelector("#System_nyHsmShk > div > div:nth-child(2) > div > form > div > div.pull-right > input");

	public UserLoginPage(WebDriver driver)
	{
		this.driver =driver;
	}
	public void typeemail(String s)
	{
		driver.findElement(email).sendKeys(s);
	}

	public void typepassword(String p) {
		driver.findElement(password).sendKeys(p);
	}
	public void clickLoginButton()
	{
		driver.findElement(loginbutton).click();
	}
	}
