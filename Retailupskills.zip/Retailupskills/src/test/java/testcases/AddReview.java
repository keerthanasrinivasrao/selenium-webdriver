package testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import pages.AdminLoginPage;

public class AddReview {
	static String driverPath = "C:\\Users\\Padma\\Desktop\\";
	@Test
	public void verifylogin()
	{
	
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://retailm1.upskills.in/admin/index.php?route=catalog/review&token=qTYnJTng6kx6cnkkMyo0BtcKtLpgVzXn");
		driver.manage().window().maximize();
		
		AdminLoginPage login = new AdminLoginPage(driver);
		
		login.typeusername("admin");
		login.typepassword("admin@123");
		login.clickLoginButton();
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[1]/div/div/a")).click();
		//*[@id="content"]/div[1]/div/div/a
		driver.findElement(By.id("input-author")).sendKeys("Keerthana");
		driver.findElement(By.id("input-product")).sendKeys("Engagement Ring");
		//WebElement product = driver.findElement(By.xpath("//*[contains(@id,'input-product')]/following-sibling::ul/child::li")); 
		//WebDriverWait wait = new WebDriverWait(driver,30);
		//driver.findElement(By.xpath("//*[contains(@id,'input-product')]/following-sibling::ul/child::li")).click();
		//*[@id="form-review"]/div[2]/div/ul/li/a
		//descendant::li[text()='Engagement ring']")
		driver.findElement(By.id("input-text")).click();
		driver.findElement(By.id("input-text")).sendKeys("Happy with the product");
		driver.findElement(By.xpath("//*[@id=\"form-review\"]/div[4]/div/label[5]/input")).click();
		driver.findElement(By.id("input-date-added")).sendKeys("2021-10-07 00:00:00");
		driver.findElement(By.xpath("//*[@id=\"input-status\"]/option[2]")).click();
		driver.findElement(By.cssSelector("#content > div.page-header > div > div > button > i")).click();
	}
}
