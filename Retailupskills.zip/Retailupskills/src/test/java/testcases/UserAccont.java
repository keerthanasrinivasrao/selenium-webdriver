package testcases;


	import java.util.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.By.ByXPath;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.Assert;
	import org.testng.Reporter;
	import org.testng.annotations.Test;

	import pages.UserLoginPage;

	public class UserAccont {
		static String driverPath = "C:\\Users\\Padma\\Desktop\\";
		@Test
		public void verifylogin()
		{
		
			System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("http://retailm1.upskills.in/account/login");
			driver.manage().window().maximize();
			
			UserLoginPage login = new UserLoginPage(driver);
			
			login.typeemail("keerthana@gmail.com");
			login.typepassword("Keerthana@4417");
			login.clickLoginButton();
			driver.findElement(By.xpath("//*[@id=\"System_nyHsmShk\"]/align/ul/li[1]/a")).click();
			driver.findElement(By.id("input-firstname")).clear();
			driver.findElement(By.id("input-firstname")).sendKeys("Gayana");
			driver.findElement(By.id("input-lastname")).clear();
			driver.findElement(By.id("input-lastname")).sendKeys("D");
			driver.findElement(By.cssSelector("#edit_account_form > div > div.pull-right > input")).click();
			WebElement msg=driver.findElement(By.xpath("//*[contains(@id,'System_nyHsmShk')]//child::div"));
			String text=msg.getText();
			Assert.assertEquals(text,"Success: Your account has been successfully updated.");
			//*[@id="System_nyHsmShk"]/div/text()
			//*[contains(@id,'System_nyHsmShk')]//child::div
		}		
}
