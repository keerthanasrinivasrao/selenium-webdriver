package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pages.AdminLoginPage;

public class DeleteReview {
	static String driverPath = "C:\\Users\\Padma\\Desktop\\";
	@Test
	public void verifylogin()
	{
	
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://retailm1.upskills.in/admin/index.php?route=catalog/review&token=qTYnJTng6kx6cnkkMyo0BtcKtLpgVzXn");
		driver.manage().window().maximize();
		
		AdminLoginPage login = new AdminLoginPage(driver);
		
		login.typeusername("admin");
		login.typepassword("admin@123");
		login.clickLoginButton();
		driver.findElement(By.cssSelector("#form-review > div > table > tbody > tr:nth-child(1) > td.text-center > input[type=checkbox]")).click();
		driver.findElement(By.cssSelector("#content > div.page-header > div > div > button")).click();
		driver.switchTo().alert().accept();
	}	
}
